from pyhon.appliances.base import ApplianceBase


class Appliance(ApplianceBase):
    pass
