AUTH_API = "https://account2.hon-smarthome.com"
API_URL = "https://api-iot.he.services"
API_KEY = "GRCqFhC6Gk@ikWXm1RmnSmX1cm,MxY-configuration"
APP = "hon"
CLIENT_ID = (
    "3MVG9QDx8IX8nP5T2Ha8ofvlmjLZl5L_gvfbT9."
    "HJvpHGKoAS_dcMN8LYpTSYeVFCraUnV.2Ag1Ki7m4znVO6"
)
APP_VERSION = "2.4.7"
OS_VERSION = 31
OS = "android"
DEVICE_MODEL = "exynos9820"
USER_AGENT = "Chrome/110.0.5481.153"
